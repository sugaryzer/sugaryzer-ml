
Low Sugar Product Recommender Based On Category - TFLite Model

Files included:
1. recommender.tflite - TensorFlow Lite model file
2. recommender_metadata.pkl - Product metadata and mappings

Instructions:
1. Place both files in your mobile app's assets folder
2. Use TensorFlow Lite interpreter to load the model
3. Load the metadata file using pickle in Python 
4. Input : product_id (barcode)
5.  We will leave the rest to MD team -goodluck!