
    Predict Consume Analyze - Model Export

    Files included:
    - sugar_model.tflite: TensorFlow Lite model file

    Instructions:
    1. Letakkan file ini di folder aset aplikasi Anda.
    2. Gunakan TensorFlow Lite Interpreter untuk membaca model ini.
    3. Referensikan README ini untuk panduan lebih lanjut.

    Semoga sukses!
    